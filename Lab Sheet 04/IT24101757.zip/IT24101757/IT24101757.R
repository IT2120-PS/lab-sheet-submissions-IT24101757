setwd("C:\\Users\\IT24101757\\Desktop\\IT24101757")
getwd()

#01
branch_data <- read.csv("Exercise.txt")
fix(branch_data)
attach(branch_data)

#03
boxplot(Sales_X1, main ="Distribution of Branch Sales", ylab = "Sales")

#04
summary(Advertising_X2)
IQR(Advertising_X2)

#05
outliers<- function(x){
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  iqr <- q3 - q1
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  print(paste("Upper Bound = " , upper_bound))
  print(paste("Lower Bound = " , lower_bound))
  print(paste("Outliers ", paste(sort(x [x < lower_bound | x > upper_bound] ) , collapse = ",")))
}

outliers(Years_X3)
